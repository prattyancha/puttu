#include"header.h"

/*
	Function name: OffBit
	Input: int
	output: int
	Discription: Toggle 7th Bit and give madified number
	Author:Prattyancha
	Date:05 sep 2020
*/

UNIT OffBit(UNIT iNo)
{
	int iMask=0x00000040;
	int iRes=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	iRes=iNo ^ iMask;
	
	return iRes;
}