#include"header.h"

/*
	Function name: OffBit
	Input: int
	output: int
	Discription: Check 7th & 10th Bit and give modified number
	Author:Prattyancha
	Date:05 sep 2020
*/

UNIT OffBit(UNIT iNo,int iPos,int iPos1)
{
	int iMask=0x00000001;
	int iMask1=0x00000001;
	int iRes=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	if((iPos<1)||(iPos>32))
	{
		return FALSE;
	}
	iMask=iMask<<(iPos-1);
	iMask1=iMask1<<(iPos1-1);
	iRes=iNo ^ iMask;
	iRes=iRes ^ iMask1;
	
	return iRes;
}