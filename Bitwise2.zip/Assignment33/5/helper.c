#include"header.h"

/*
	Function name: OnBit
	Input: int
	output: int
	Discription: on first 4 Bits and give madified number
	Author:Prattyancha
	Date:05 sep 2020
*/

UNIT OnBit(UNIT iNo)
{
	int iMask=0x0000000F;
	int iRes=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	iRes=iNo | iMask;
	return iRes;
}