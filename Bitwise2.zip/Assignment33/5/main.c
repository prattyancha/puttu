#include"header.h"

int main()
{
	unsigned int iNo=0;
	int iRet=0;
	
	printf("Enter no:\n");
	scanf("%d",&iNo);
	
	iRet=OnBit(iNo);
	
	printf("MODIFIED NUMBER::%d",iRet);
	
	return 0;
}