#include"header.h"

int main()
{
	unsigned int iNo=0;
	int iPos=0,iPos1=0,iRet=0;
	
	printf("Enter no:\n");
	scanf("%d",&iNo);
	
	printf("Enter Position of BIT:\n");
	scanf("%d",&iPos);
	
	printf("Enter Position of BIT:\n");
	scanf("%d",&iPos1);
	
	iRet=ToggleBit(iNo,iPos,iPos1);
	
	printf("MODIFIED NUMBER::%d",iRet);
	
	return 0;
}