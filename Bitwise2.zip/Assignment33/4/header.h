#include<stdio.h>
typedef unsigned int UNIT;
#define TRUE 1
#define FALSE 0
UNIT ToggleBit(UNIT,int,int);