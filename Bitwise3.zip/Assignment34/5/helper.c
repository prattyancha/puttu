#include"header.h"

/*
	Function name: ToggleBit
	Input: int
	output: int
	Discription: Toggle Bit and give madified number
	Author:Prattyancha
	Date:05 sep 2020
*/

UNIT ToggleBit(UNIT iNo)
{
	int iMask=0xF000000F;
	int iRes=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	~iMask;
	iRes=iNo ^ iMask;
	
	return iRes;
}