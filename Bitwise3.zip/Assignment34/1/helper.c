#include"header.h"

/*
	Function name: ChkBit
	Input: int
	output: BOOL
	Discription: Check 15th bit on or off
	Author:Prattyancha
	Date:04 sep 2020
*/

BOOL ChkBit(UINT iNo,int iPos)
{
	int iMask=0x00000001;
	int iRes=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	iMask=iMask<<(iPos-1);
	iRes=iNo & iMask;
	
	if(iRes==iMask)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}