#include"header.h"
int main()
{
	unsigned int iNo=0;
	int iPos=0;
	BOOL bRet=FALSE;
	
	printf("Enter no:\n");
	scanf("%d",&iNo);
	
	printf("Enter Position:\n");
	scanf("%d",&iPos);
	
	bRet=ChkBit(iNo,iPos);
	if(bRet==TRUE)
	{
		printf("Bit is ON...");
	}
	else
	{
		printf("Bit is OFF....");
	}
	
	return 0;
}