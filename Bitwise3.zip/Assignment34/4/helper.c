#include"header.h"

/*
	Function name: ToggleBit
	Input: int
	output: int
	Discription: Toggle Bit and give madified number
	Author:Prattyancha
	Date:05 sep 2020
*/

UNIT ToggleBit(UNIT iNo,int iPos)
{
	int iMask=0x00000001;
	int iRes=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	if((iPos<1)||(iPos>32))
	{
		return FALSE;
	}
	iMask=iMask<<(iPos-1);
	iRes=iNo ^ iMask;
	
	return iRes;
}