#include<stdio.h>
typedef unsigned int UNIT;
#define TRUE 1
#define FALSE 0
UNIT OnBit(UNIT,int);