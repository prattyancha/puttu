#include"header.h"

/*
	Function name: ChkBit
	Input: int
	output: BOOL
	Discription: Check FIRST & LAST Bit is ON or OFF
	Author:Prattyancha
	Date:04 sep 2020
*/

BOOL ChkBit(UNIT iNo)
{
	int iMask=0x80000001;
	int iRes=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	iRes=iNo & iMask;
	
	if(iRes==iMask)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}