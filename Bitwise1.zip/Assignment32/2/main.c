#include"header.h"
int main()
{
	unsigned int iNo=0;
	BOOL bRet=FALSE;
	
	printf("Enter no:\n");
	scanf("%d",&iNo);
	
	bRet=ChkBit(iNo);
	if(bRet==TRUE)
	{
		printf("5th & 18th Bit is ON...");
	}
	else
	{
		printf("Bit is OFF....");
	}
	
	return 0;
}