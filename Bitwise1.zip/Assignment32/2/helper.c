#include"header.h"

/*
	Function name: ChkBit
	Input: int
	output: BOOL
	Discription: Check 5th & 18th bit on or off
	Author:Prattyancha
	Date:04 sep 2020
*/

BOOL ChkBit(UNIT iNo)
{
	int iMask=0x00020010;
	int iRes=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	iRes=iNo & iMask;
	
	if(iRes==iMask)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}