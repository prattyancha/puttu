#include"header.h"

/*
	Function name: ChkBit
	Input: int
	output: BOOL
	Discription: Check 7th,15th,21th&28th Bit is ON or off
	Author:Prattyancha
	Date:04 sep 2020
*/

BOOL ChkBit(UNIT iNo)
{
	int iMask=0x08104040;
	int iRes=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	iRes=iNo & iMask;
	
	if(iRes==iMask)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}