#include<stdio.h>
typedef int BOOL;
typedef unsigned int UNIT;
#define TRUE 1
#define FALSE 0
BOOL ChkBit(UNIT);
