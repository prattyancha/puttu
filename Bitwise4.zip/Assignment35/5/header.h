#include<stdio.h>
typedef unsigned int UINT;
#define TRUE 1
#define FALSE 0
int ChkBit(UINT,int,int);