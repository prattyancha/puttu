#include"header.h"

/*
	Function name: ChkBit
	Input: int
	output: int
	Discription: Check Bit on or off of given positions and give modified number
	Author:Prattyancha
	Date:05 sep 2020
*/
int ChkBit(UINT iNo,int iStart,int iEnd)
{
	int iMask=0x00000001;
	int iRes=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}

	iRes=((1<<iEnd)-1) ^ ((iStart<<(iStart-1))-1);
	
	return iNo ^ iRes;
	
	
}