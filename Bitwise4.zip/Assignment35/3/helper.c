#include"header.h"

/*
	Function name: ChkBit
	Input: int
	output: BOOL
	Discription: Check 9th & 12th bit on or off
	Author:Prattyancha
	Date:08 sep 2020
*/

BOOL ChkBit(UINT iNo)
{
	int iMask=0x00000100,iMask1=0x00000800;
	int iRes=0,iRes1=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	iRes=iNo & iMask;
	iRes1=iNo & iMask1;
	
	if(iRes==iMask  || iRes1==iMask1)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}