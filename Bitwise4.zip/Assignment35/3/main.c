#include"header.h"
int main()
{
	unsigned int iNo=0;
	BOOL bRet=FALSE,bRet1=FALSE;
	
	printf("Enter no:\n");
	scanf("%d",&iNo);
	
	bRet=ChkBit(iNo);
	if(bRet==TRUE || bRet1==TRUE)
	{
		printf("9th & 12th Bit is ON...");
	}
	else
	{
		printf("Bit is OFF....");
	}
	
	return 0;
}