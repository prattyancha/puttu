#include"header.h"

/*
	Function name: ChkBit
	Input: int
	output: int
	Discription: Check Bit on or off of given positions and give modified number
	Author:Prattyancha
	Date:05 sep 2020
*/

BOOL ChkBit(UINT iNo,int iPos,int iPos1)
{
	int iMask=0x00000001;
	int iMask1=0x00000001;
	int iRes=0,iRes1=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}

	iMask=iMask<<(iPos-1);
	iRes=iNo & iMask;
	
	iMask1=iMask1<<(iPos1-1);
	iRes1=iNo & iMask1;
	
	if(iRes==iMask || iRes1==iMask1)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}