#include"header.h"

int main()
{
	unsigned int iNo=0;
	int iPos=0,iPos1=0;
	BOOL bRet=FALSE,bRet1=FALSE;
	
	printf("Enter no:\n");
	scanf("%d",&iNo);
	
	printf("Enter Position of BIT:\n");
	scanf("%d",&iPos);
	
	printf("Enter Position of BIT:\n");
	scanf("%d",&iPos1);
	
	bRet=ChkBit(iNo,iPos,iPos1);
	
	if(bRet==TRUE || iPos1==TRUE)
	{
		printf("BITS are on");
	}
	else
	{
		printf("BITS are off");
	}
	
	return 0;
}