#include"header.h"

/*
	Function name: CountOne
	Input: int
	output: int
	Discription: count on BIts..
	Author:Prattyancha
	Date:05 sep 2020
*/

UINT CountOne(UINT iNo)
{
	int iMask=0x00000001;
	int iRes=0,iCnt=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	while(iNo!=0)
	{
		if((iNo & iMask) == iMask)
		{
			iCnt++;
		}
		iNo=iNo>>iMask;
	}
	return iCnt;
}