#include"header.h"

int main()
{
	unsigned int iNo=0;
	int iRet=0;
	
	printf("Enter no:\n");
	scanf("%d",&iNo);
	
	iRet=CountOne(iNo);
	printf("NUMBER of ON bits::%d",iRet);
	return 0;
}