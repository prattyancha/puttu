#include"header.h"

/*
	Function name: CommonOn
	Input: int
	output: int
	Discription: count on BIts..
	Author:Prattyancha
	Date:05 sep 2020
*/

UINT CommonOn(UINT iNo,UINT iNo1)
{
	int iMask=0x00000001,iMask1=0x00000001;
	int iRes=0,iCnt=0,iPos=0,iRes1=0,iCnt1=0;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	
	iRes=iNo & iMask;
	iRes1=iNo1 & iMask;
	
	if(iRes1==iMask || iRes==iMask)
	{
		iPos=iCnt;
		iCnt++;
	}
	iNo=iNo>>iMask;
	iNo1=iNo1>>iMask;
	return iPos;
}