#include<stdio.h>
typedef unsigned int UINT;
#define TRUE 1
#define FALSE 0
UINT CommonOn(UINT,UINT);