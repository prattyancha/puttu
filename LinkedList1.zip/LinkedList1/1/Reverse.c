#include<stdio.h>
#include<stdlib.h>
struct Node
{
	int data;
	struct Node* next;
};


typedef struct Node NODE; 				//NODE is considered as another name for struct Node
typedef struct Node *PNODE;				//PNODE is considered as another name for struct Node*
typedef struct Node **PPNODE;			//PPNODE is considered as another name for struct Node**

/*
	allocate memory for node 
	initialize that node 
	check linkedlist is empty or not
	Insert the node accordingly
*/
//				(pahilya mulacha address,input)
void InsertFirst(PPNODE Head,int value)
{
	//int pos=0;
	PNODE newn=NULL;
	//						next chi value
	newn=(PNODE)malloc(sizeof(NODE));
	newn->data=value;
	newn->next=NULL;
	
	if(*Head==NULL)		//if linkedist is empty
	{
		*Head=newn;
	}
	else				//if linkedlist contains atleast one node
	{
		newn->next=*Head;
		*Head=newn;
	}
}

void Reverse(PNODE Head)
{
	
	while(Head!=NULL)
	{
		int rem=0,reverse=0;
		while(Head->data!=0)
		{
			rem=(Head->data)%10;
			reverse=(reverse*10)+rem;
			Head->data/=10;
		}
		printf("%d  ",reverse);
		Head=Head->next;
	}
}

void Display(PNODE Head)
{
	printf("\n");
	while(Head!=NULL)
	{
		printf("|%d|->",Head->data);
		Head=Head->next;
	}
	printf("NULL\n");
}

int Count(PNODE Head)
{
	int iCnt=0;
	while(Head!=NULL)
	{
		iCnt++;
		Head=Head->next;
	}
	return iCnt;
}

int main()
{
	PNODE First=NULL;    //First node to be keep in mind
	int no=0,iRet=0;
	printf("Enter no:\n");
	scanf("%d",&no);
	InsertFirst(&First,no);
	
	printf("Enter no:\n");
	scanf("%d",&no);
	InsertFirst(&First,no);
	
	printf("Enter no:\n");
	scanf("%d",&no);
	InsertFirst(&First,no);

	printf("\nEnter no:");
	scanf("%d",&no);
	InsertFirst(&First,no);
	
	
	printf("\nEnter no:");
	scanf("%d",&no);
	InsertFirst(&First,no);
	
	Display(First);
	
	Reverse(First);
	
	return 0;
}